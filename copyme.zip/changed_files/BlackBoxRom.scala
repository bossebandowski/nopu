/*
 * Black Box ROM to fix Chisel 2 to Chisel 3 migration issue in patmos Fetch stage
 * based on https://www.chisel-lang.org/chisel3/docs/explanations/blackboxes.html
 *
 * Author: Bosse Bandowski (bosse.bandowski@outlook.com)
 *
 */

package util


import chisel3._
import chisel3.util.HasBlackBoxInline
import patmos.Constants._

class BlackBoxRom(romContents : Array[BigInt], addrWidth : Int) extends BlackBox with HasBlackBoxInline {
    
    val io = IO(new Bundle {
        val address = Input(UInt(addrWidth.W))
        val instruction = Output(UInt(INSTR_WIDTH.W))
    })

    val romLinePattern = "\t|\t%d: instruction = %d'h%x;\n"


    val HEADER =    """
        module BlackBoxRom(
        |    input  [%d:0] address,
        |    output [%d:0] instruction
        |);
        |always @(*) case (address)
        """.format(addrWidth - 1, INSTR_WIDTH - 1)
                    
    val FOOTER =    """
        |    default: begin
        |        instruction = %d'bx;
        |        `ifndef SYNTHESIS
        |            // synthesis translate_off
        |            instruction = {1{$random}};
        |            // synthesis translate_on
        |        `endif
        |    end
        |endcase
        |endmodule
        """.format(INSTR_WIDTH)

    var BODY = "\n"

    for (id <- 0 to romContents.length - 1) {
        BODY = BODY + romLinePattern.format(id, INSTR_WIDTH, romContents(id))
    }

    setInline("BlackBoxRom.v", (HEADER + BODY + FOOTER).stripMargin)
}